<html>
<head>
    <meta charset="utf-8">
    <title>Illinois State University - Men's Water Polo RSO</title>
    <link id="main_css" href="../styles/style41.css" rel="stylesheet">
    <link href="../styles/easy-responsive-tabs.css" rel="stylesheet">
</head>
<body>
<?php include 'navbar.html'; ?>
    <main>
        <section class="about-us">
            <h1>Here's a look at our scores!</h1>
        </section>
    </main>
<?php include 'footer.html'; ?>
<script src="../js/external-js.js></script>
</body>	
</html>
