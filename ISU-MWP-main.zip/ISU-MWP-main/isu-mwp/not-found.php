<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Illinois State University - Men's Water Polo RSO</title>
    <link id="main_css" href="../styles/style41.css" rel="stylesheet">
    <link href="../styles/easy-responsive-tabs.css" rel="stylesheet">
    <link href="../styles/additional-styles.css" rel="stylesheet">
    <?php include 'navbar.html'; ?>
    <style>
.center-message {
    display: flex;
    justify-content: center; /* Horizontally centers the content */
    align-items: center;     /* Vertically centers the content */
    height: 80vh;           /* Use full viewport height */
    text-align: center;      /* Center text inside the paragraph */
}

.center-message p {
    font-style: italic; /* Italicize the text */
}
</style>
<div class="center-message">
    <p>This page couldn't be found, does not exist yet, or you are not authorized to access it.</p>
</div>
